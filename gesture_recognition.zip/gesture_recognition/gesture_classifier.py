import numpy as np
from collections import deque

class GestureClassifier:
    def __init__(self):
        # Define finger indices
        self.finger_tips = [4, 8, 12, 16, 20]
        self.finger_pips = [3, 7, 11, 15, 19]
        
        # Gesture history for smoothing
        self.gesture_history = deque(maxlen=5)

    def classify_gesture(self, landmarks):
        # Get finger states
        finger_states = self._get_finger_states(landmarks)
        
        # Classify the gesture based on finger states
        gesture, confidence = self._determine_gesture(finger_states)
        
        # Apply smoothing
        smoothed_gesture = self._smooth_gesture(gesture, confidence)
        
        return smoothed_gesture, confidence

    def _get_finger_states(self, landmarks):
        """Determine if each finger is raised"""
        finger_states = []
        
        # Check thumb separately (using x-coordinate)
        thumb_tip = landmarks.landmark[self.finger_tips[0]].x
        thumb_pip = landmarks.landmark[self.finger_pips[0]].x
        finger_states.append(thumb_tip < thumb_pip)
        
        # Check other fingers (using y-coordinate)
        for tip, pip in zip(self.finger_tips[1:], self.finger_pips[1:]):
            tip_y = landmarks.landmark[tip].y
            pip_y = landmarks.landmark[pip].y
            finger_states.append(tip_y < pip_y)
            
        return finger_states

    def _determine_gesture(self, finger_states):
        """Map finger states to gestures"""
        if all(finger_states):
            return "FIVE", 0.9
        elif not any(finger_states):
            return "FIST", 0.9
        elif finger_states[1] and not any([finger_states[0], finger_states[2], finger_states[3], finger_states[4]]):
            return "ONE", 0.85
        elif finger_states[1] and finger_states[2] and not any([finger_states[0], finger_states[3], finger_states[4]]):
            return "PEACE", 0.85
        elif finger_states[0] and not any(finger_states[1:]):
            return "THUMBS_UP", 0.85
        else:
            return "UNKNOWN", 0.5

    def _smooth_gesture(self, gesture, confidence):
        """Apply temporal smoothing to gestures"""
        if confidence > 0.7:
            self.gesture_history.append(gesture)
            if len(self.gesture_history) >= 3:
                return max(set(self.gesture_history), key=self.gesture_history.count)
        return gesture 